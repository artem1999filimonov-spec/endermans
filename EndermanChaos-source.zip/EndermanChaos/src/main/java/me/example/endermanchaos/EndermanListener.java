package me.example.endermanchaos;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Boat;
import org.bukkit.entity.ChestBoat;
import org.bukkit.entity.Enderman;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.player.PlayerVehicleEnterEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public final class EndermanListener implements Listener {
    private static final double AGGRO_RADIUS = 16.0;
    private static final double BOAT_RADIUS = 8.0;
    private static final double ARENA_DISTANCE = 1000.0;

    private final EndermanChaos plugin;
    private final Random random = new Random();
    private final Map<UUID, Long> arenaCooldowns = new HashMap<>();

    public EndermanListener(EndermanChaos plugin) {
        this.plugin = plugin;
    }

    /*
     * Запускается главным классом раз в 20 тиков.
     * Для каждого эндермена с целью-игроком выполняется один цикл кражи.
     */
    public void runBlockTheftCycle() {
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (!(entity instanceof Enderman enderman) || !enderman.isValid() || enderman.isDead()) {
                    continue;
                }
                if (!(enderman.getTarget() instanceof Player player) || !player.isOnline()
                        || player.isDead()) {
                    continue;
                }
                if (enderman.getLocation().distanceSquared(player.getLocation()) > AGGRO_RADIUS * AGGRO_RADIUS) {
                    continue;
                }
                stealBlockAndBuildObstacle(enderman, player);
            }
        }
    }

    private void stealBlockAndBuildObstacle(Enderman enderman, Player player) {
        Block source = findNearestBlockBelowHead(enderman);
        if (source == null) {
            return;
        }

        BlockData carried = source.getBlockData().clone();
        Location endermanReturn = enderman.getLocation().clone();

        // Эндермен перемещается к выбранному блоку и забирает его.
        Location blockSpot = source.getLocation().add(0.5, 1.0, 0.5);
        enderman.teleport(blockSpot);
        source.setType(Material.AIR, false);
        enderman.setCarriedBlock(carried);

        // Возвращается к игроку и ставит блок рядом, если место свободно.
        enderman.teleport(endermanReturn);
        Block placement = findPlacementNearPlayer(player);
        if (placement != null) {
            placement.setBlockData(carried, false);
            enderman.setCarriedBlock(null);
        }
    }

    private Block findNearestBlockBelowHead(Enderman enderman) {
        Location base = enderman.getLocation();
        int minY = Math.max(enderman.getWorld().getMinHeight(), base.getBlockY());
        int maxY = Math.min(enderman.getWorld().getMaxHeight() - 1,
                (int) Math.floor(enderman.getEyeLocation().getY()));

        Block best = null;
        double bestDistance = Double.MAX_VALUE;

        for (int x = base.getBlockX() - 4; x <= base.getBlockX() + 4; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = base.getBlockZ() - 4; z <= base.getBlockZ() + 4; z++) {
                    Block block = enderman.getWorld().getBlockAt(x, y, z);
                    Material type = block.getType();
                    if (type.isAir() || !block.getType().isSolid() || block.isLiquid()
                            || block.getState() instanceof org.bukkit.block.TileState) {
                        continue;
                    }
                    double distance = block.getLocation().distanceSquared(base);
                    if (distance < bestDistance) {
                        bestDistance = distance;
                        best = block;
                    }
                }
            }
        }
        return best;
    }

    private Block findPlacementNearPlayer(Player player) {
        Location p = player.getLocation();
        int[][] offsets = {
                {1, 0}, {-1, 0}, {0, 1}, {0, -1},
                {1, 1}, {1, -1}, {-1, 1}, {-1, -1}
        };

        for (int[] offset : offsets) {
            Block floor = p.getWorld().getBlockAt(p.getBlockX() + offset[0],
                    p.getBlockY() - 1, p.getBlockZ() + offset[1]);
            Block target = p.getWorld().getBlockAt(p.getBlockX() + offset[0],
                    p.getBlockY(), p.getBlockZ() + offset[1]);
            Block above = target.getRelative(0, 1, 0);
            if (floor.getType().isSolid() && target.getType().isAir() && above.getType().isAir()) {
                return target;
            }
        }
        return null;
    }

    @EventHandler
    public void onVehicleEnter(PlayerVehicleEnterEvent event) {
        Entity vehicle = event.getVehicle();
        if (!(vehicle instanceof Boat) && !(vehicle instanceof ChestBoat)) {
            return;
        }

        Player player = event.getEntered() instanceof Player p ? p : null;
        if (player == null) {
            return;
        }

        boolean nearby = false;
        for (Entity entity : player.getNearbyEntities(BOAT_RADIUS, BOAT_RADIUS, BOAT_RADIUS)) {
            if (entity instanceof Enderman enderman && enderman.isValid() && !enderman.isDead()) {
                nearby = true;
                break;
            }
        }
        if (!nearby) {
            return;
        }

        event.setCancelled(true);
        // Один тик задержки: гарантированно после обработки события посадки.
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!vehicle.isValid()) {
                player.leaveVehicle();
                return;
            }
            player.leaveVehicle();
            vehicle.remove();
        }, 1L);
    }

    @EventHandler
    public void onEndermanAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Enderman enderman)
                || !(event.getEntity() instanceof Player player)) {
            return;
        }

        long now = System.currentTimeMillis();
        Long last = arenaCooldowns.get(player.getUniqueId());
        if (last != null && now - last < 3000L) {
            return;
        }
        arenaCooldowns.put(player.getUniqueId(), now);

        Location origin = player.getLocation().clone();
        Location destination = findArenaLocation(origin);
        if (destination == null) {
            plugin.getLogger().warning("Не удалось найти безопасное место для арены.");
            return;
        }

        // Перемещение обоих участников через 20 тиков.
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || !enderman.isValid() || enderman.isDead()) {
                    return;
                }
                Location playerSpot = destination.clone();
                playerSpot.setYaw(player.getLocation().getYaw());
                playerSpot.setPitch(player.getLocation().getPitch());

                Location endermanSpot = destination.clone().add(2.0, 0.0, 0.0);
                player.teleport(playerSpot);
                enderman.teleport(endermanSpot);
            }
        }.runTaskLater(plugin, 20L);
    }

    private Location findArenaLocation(Location origin) {
        World world = origin.getWorld();
        if (world == null) {
            return null;
        }

        double angle = random.nextDouble() * Math.PI * 2.0;
        // Поворачиваем направление, сохраняя горизонтальное расстояние ровно 1000 блоков.
        for (int attempt = 0; attempt < 24; attempt++) {
            double a = angle + (Math.PI * 2.0 * attempt / 24.0);
            int x = (int) Math.round(origin.getX() + Math.cos(a) * ARENA_DISTANCE);
            int z = (int) Math.round(origin.getZ() + Math.sin(a) * ARENA_DISTANCE);

            if (Math.abs(x) > world.getWorldBorder().getSize() / 2.0
                    || Math.abs(z) > world.getWorldBorder().getSize() / 2.0) {
                continue;
            }

            int y = world.getHighestBlockYAt(x, z);
            if (y <= world.getMinHeight() || y + 2 >= world.getMaxHeight()) {
                continue;
            }

            Block ground = world.getBlockAt(x, y - 1, z);
            Block feet = world.getBlockAt(x, y, z);
            Block head = world.getBlockAt(x, y + 1, z);

            if (ground.getType().isSolid() && feet.getType().isAir() && head.getType().isAir()
                    && !ground.isLiquid()) {
                return new Location(world, x + 0.5, y, z + 0.5);
            }
        }
        return null;
    }
}
