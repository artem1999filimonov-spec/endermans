package me.example.endermanchaos;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class EndermanChaos extends JavaPlugin {
    private EndermanListener listener;

    @Override
    public void onEnable() {
        listener = new EndermanListener(this);
        getServer().getPluginManager().registerEvents(listener, this);

        // Проверка активных эндерменов раз в секунду (20 тиков).
        Bukkit.getScheduler().runTaskTimer(this, listener::runBlockTheftCycle, 20L, 20L);
        getLogger().info("EndermanChaos включён.");
    }

    @Override
    public void onDisable() {
        getLogger().info("EndermanChaos выключен.");
    }
}
